import SwiftUI

extension View {
    func actionBar(padding: CGFloat = 10, @ViewBuilder content: () -> some View) -> some View {
        self
            .padding(.bottom, 24)
            .overlay(alignment: .bottom) {
                VStack(spacing: 0) {
                    Divider()
                    HStack(spacing: 0) {
                        content()
                    }
                    .buttonStyle(.plain)
                    .frame(height: 16)
                    .padding(.vertical, 4)
                    .padding(.horizontal, padding)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(height: 24)
                .background(Color.blue)
            }
    }
}
