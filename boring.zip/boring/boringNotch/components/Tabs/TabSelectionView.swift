//
//  TabSelectionView.swift
//  boringNotch
//
//  Created by Hugo Persson on 2024-08-25.
//

import SwiftUI

struct TabModel: Identifiable {
    let id = UUID()
    let label: String
    let icon: String
    let view: NotchViews
}

let tabs = [
    TabModel(label: "Home", icon: "house.fill", view: .home),
    TabModel(label: "Shelf", icon: "tray.fill", view: .shelf)
]

struct TabSelectionView: View {
    @ObservedObject var coordinator = BoringViewCoordinator.shared
    @Namespace var animation

    var body: some View {
        HStack(spacing: 0) {
            ForEach(tabs) { tab in
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        coordinator.currentView = tab.view
                    }
                }) {
                    HStack(spacing: 6) {
                        Image(systemName: tab.icon)
                        Text(tab.label)
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 6)
                    .foregroundColor(coordinator.currentView == tab.view ? .white : .gray)
                    .background {
                        if coordinator.currentView == tab.view {
                            Capsule()
                                .fill(Color(nsColor: .secondarySystemFill).opacity(0.3))
                                .matchedGeometryEffect(id: "capsule", in: animation)
                        }
                    }
                }
                .buttonStyle(.plain)
                .frame(height: 28)
            }
        }
        .background(Color.clear)
        .clipShape(Capsule())
    }
}


#Preview {
    BoringHeader().environmentObject(BoringViewModel())
}
