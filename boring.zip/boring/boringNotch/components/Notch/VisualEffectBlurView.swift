//
//  VisualEffectBlurView.swift
//  boringNotch
//
//  Created by Ely Wright on 7/6/25.
//


import SwiftUI

struct VisualEffectBlurView: NSViewRepresentable {
    func makeNSView(context: Context) -> NSVisualEffectView {
        let view = NSVisualEffectView()
        view.blendingMode = .behindWindow
        view.material = .hudWindow  // You can try .sidebar, .popover, .underWindowBackground, etc.
        view.state = .active
        return view
    }

    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {
        // Nothing to update dynamically here
    }
}
