import SwiftUI

struct NotchShelfView: View {
    @EnvironmentObject var vm: BoringViewModel
    @StateObject var tvm = TrayDrop.shared
    
    // Spacing for drop items
    private let spacing: CGFloat = 8
    
    var body: some View {
        HStack(spacing: spacing) {
            AirDropView()
            
            panel
                .onDrop(of: [.data], isTargeted: $vm.dropZoneTargeting) { providers in
                    vm.dropEvent = true
                    DispatchQueue.global().async {
                        tvm.load(providers)
                    }
                    return true
                }
        }
        .padding(12)
        .background(
            // Blur background matching Dynamic Island style
            VisualEffectBlurView()
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.15), lineWidth: 1)
        )
        .animation(vm.animation, value: tvm.items)
        .animation(vm.animation, value: tvm.isLoading)
    }
    
    var panel: some View {
        RoundedRectangle(cornerRadius: 16)
            .strokeBorder(style: StrokeStyle(lineWidth: 3, dash: [8]))
            .foregroundStyle(Color.white.opacity(0.15))
            .overlay {
                content
                    .padding()
            }
    }
    
    var content: some View {
        Group {
            if tvm.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "tray.and.arrow.down")
                        .symbolVariant(.fill)
                        .symbolRenderingMode(.hierarchical)
                        .foregroundStyle(.white, .gray)
                        .imageScale(.large)
                    
                    Text("Drop files here")
                        .foregroundStyle(.gray)
                        .font(.system(.title3, design: .rounded))
                        .fontWeight(.medium)
                }
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: spacing) {
                        ForEach(tvm.items) { item in
                            DropItemView(item: item)
                        }
                    }
                    .padding(spacing)
                }
                .padding(-spacing)
            }
        }
    }
}
