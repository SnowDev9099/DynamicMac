import SwiftUI

struct NotchShape: Shape {
    private var topCornerRadius: CGFloat
    private var bottomCornerRadius: CGFloat

    init(
        topCornerRadius: CGFloat? = nil,
        bottomCornerRadius: CGFloat? = nil
    ) {
        self.topCornerRadius = topCornerRadius ?? 45
        self.bottomCornerRadius = bottomCornerRadius ?? 45
    }

    var animatableData: AnimatablePair<CGFloat, CGFloat> {
        get {
            .init(topCornerRadius, bottomCornerRadius)
        }
        set {
            topCornerRadius = newValue.first
            bottomCornerRadius = newValue.second
        }
    }

    func path(in rect: CGRect) -> Path {
        // Use the smaller of the requested radius or half the height for pill shape
        let radius = min(min(topCornerRadius, bottomCornerRadius), rect.height / 2)
        return RoundedRectangle(cornerRadius: radius, style: .continuous).path(in: rect)
    }
}

#Preview {
    NotchShape(topCornerRadius: 45, bottomCornerRadius: 45)
        .fill(.black.opacity(0.8))
        .frame(width: 380, height: 90)
        .padding()
}
