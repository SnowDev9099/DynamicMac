//
//  constants.swift
//  boringNotch
//
//  Created by Harsh Vardhan  Goswami  on 04/08/24.
//

import Foundation

let productPage = URL(string: "https://github.com/TheBoredTeam/boring.notch")!
let sponsorPage = URL(string: "https://buymeacoffee.com/jfxh67wvfxq")!


